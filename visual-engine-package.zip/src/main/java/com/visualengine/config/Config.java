package com.visualengine.config;

import java.io.File;

public class Config {
    public enum ExecutionMode {
        BASELINE, COMPARE, APPROVAL, HEAL
    }

    public static ExecutionMode MODE;
    public static final String BASELINE_DIR = System.getProperty("user.dir") + "/visual_baselines";
    public static final String REPORTS_DIR = System.getProperty("user.dir") + "/visual_reports";
    public static final String LOCATOR_MAP_FILE = System.getProperty("user.dir") + "/locator_map.json";
    
    public static final double PIXEL_MATCH_THRESHOLD;
    public static final String OPENAI_API_KEY;

    static {
        String modeStr = System.getenv("VISUAL_EXECUTION_MODE");
        MODE = (modeStr != null) ? ExecutionMode.valueOf(modeStr.toUpperCase()) : ExecutionMode.COMPARE;

        String thresholdStr = System.getenv("PIXEL_MATCH_THRESHOLD");
        PIXEL_MATCH_THRESHOLD = (thresholdStr != null) ? Double.parseDouble(thresholdStr) : 0.98;

        String apiKey = System.getenv("OPENAI_API_KEY");
        OPENAI_API_KEY = (apiKey != null) ? apiKey : "";

        new File(BASELINE_DIR).mkdirs();
        new File(REPORTS_DIR).mkdirs();
    }
}
