package com.visualengine.engine;

import com.visualengine.config.Config;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import com.google.gson.Gson;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class VisualCheckpoint {
    private final VisualComparisonEngine engine;
    private final AIReviewer ai;
    public static final List<Map<String, Object>> results = new ArrayList<>();

    public VisualCheckpoint() {
        this.engine = new VisualComparisonEngine(Config.PIXEL_MATCH_THRESHOLD);
        this.ai = new AIReviewer();
    }

    public boolean validateStep(WebDriver driver, String pageName, List<VisualComparisonEngine.Region> ignoreRegions) throws IOException {
        String baseImgPath = Config.BASELINE_DIR + "/" + pageName + ".png";
        String baseDomPath = Config.BASELINE_DIR + "/" + pageName + ".html";
        
        String actualImgPath = Config.REPORTS_DIR + "/" + pageName + "_actual.png";
        String actualDomPath = Config.REPORTS_DIR + "/" + pageName + "_actual.html";
        String diffImgPath = Config.REPORTS_DIR + "/" + pageName + "_diff.png";

        File actualScreenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        Files.copy(actualScreenshot.toPath(), new File(actualImgPath).toPath(), StandardCopyOption.REPLACE_EXISTING);
        
        String actualDom = DOMParser.captureDOMSnapshot(driver);
        try (FileWriter fw = new FileWriter(actualDomPath)) { fw.write(actualDom); }
        Map<String, Object> metadata = DOMParser.extractMetadata(driver, pageName);

        Map<String, Object> result = new java.util.HashMap<>();
        result.put("scenario", pageName);
        result.put("mode", Config.MODE.name());
        result.put("actual_img", actualImgPath);
        result.put("baseline_img", baseImgPath);
        result.put("passed", true);
        result.put("classification", "N/A");

        if (Config.MODE == Config.ExecutionMode.BASELINE) {
            Files.copy(actualScreenshot.toPath(), new File(baseImgPath).toPath(), StandardCopyOption.REPLACE_EXISTING);
            try (FileWriter fw = new FileWriter(baseDomPath)) { fw.write(actualDom); }
            System.out.println("Baseline saved for " + pageName);
            results.add(result);
            return true;
        } else if (Config.MODE == Config.ExecutionMode.COMPARE) {
            if (!new File(baseImgPath).exists()) {
                throw new RuntimeException("Baseline missing for " + pageName);
            }

            VisualComparisonEngine.ComparisonResult compRes = engine.compareImages(baseImgPath, actualImgPath, diffImgPath, ignoreRegions);
            result.put("score", compRes.score);
            result.put("passed", compRes.passed);
            result.put("diff_img", diffImgPath);

            if (!compRes.passed) {
                System.out.println("Visual difference detected. Triggering AI...");
                String baseDom = new String(Files.readAllBytes(new File(baseDomPath).toPath()));
                Map<String, Integer> domDiff = DOMParser.compareDOMs(baseDom, actualDom);
                String classification = ai.classifyDiff(compRes.score, domDiff, metadata);
                result.put("classification", classification);
                
                if (!"EXPECTED_CHANGE".equals(classification)) {
                    result.put("passed", false);
                } else {
                    result.put("passed", true); // or false based on policy
                }
            }

            results.add(result);
            return (boolean) result.get("passed");
        }
        return true;
    }
}
