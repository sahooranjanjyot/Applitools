package com.visualengine.engine;

import com.visualengine.config.Config;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

public class Reporter {
    public static void generateReport() {
        if (VisualCheckpoint.results.isEmpty()) return;

        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html><html><head><style>")
            .append("body{font-family:Arial;} .pass{color:green;} .fail{color:red;} img{width:100%;}")
            .append(".col{float:left; width:33%; padding:5px; box-sizing:border-box;} .row::after{content:''; clear:both; display:table;}")
            .append("</style></head><body><h1>Visual Validation Report</h1>");

        for (Map<String, Object> res : VisualCheckpoint.results) {
            boolean passed = (boolean) res.get("passed");
            html.append("<h2>Scenario: ").append(res.get("scenario")).append("</h2>")
                .append("<p>Status: <span class='").append(passed ? "pass" : "fail").append("'>")
                .append(passed ? "PASS" : "FAIL").append("</span></p>")
                .append("<p>Classification: ").append(res.get("classification")).append("</p>");

            html.append("<div class='row'>")
                .append("<div class='col'><h3>Baseline</h3><img src='file://").append(res.get("baseline_img")).append("'></div>");
            
            if (res.containsKey("actual_img")) {
                html.append("<div class='col'><h3>Actual</h3><img src='file://").append(res.get("actual_img")).append("'></div>");
            }
            if (res.containsKey("diff_img") && res.get("diff_img") != null) {
                html.append("<div class='col'><h3>Diff</h3><img src='file://").append(res.get("diff_img")).append("'></div>");
            }
            html.append("</div><hr>");
        }
        html.append("</body></html>");

        String filename = Config.REPORTS_DIR + "/report_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".html";
        try (FileWriter fw = new FileWriter(filename)) {
            fw.write(html.toString());
            System.out.println("Visual QA Report generated at: " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
